<?php

    require("../includes/config.php");
	
		redirect("../");
		
		
			
		
?>
