<?php
    // configuration
    
	
    render("public/404_system/404form.php");
    
    if($_SERVER["REQUEST_METHOD"] === "POST") {
		
		
    }
	else {
		if(isset($_GET["action"])) {
			
		}
		else {
			
		}
	}
?>
